create definer = root@`%` view v_grade as
select `grade`.`id`          AS `id`,
       `grade`.`event_type`  AS `event_type`,
       `grade`.`deal_user`   AS `deal_user`,
       `grade`.`grade`       AS `grade`,
       `grade`.`create_time` AS `create_time`,
       `grade`.`title`       AS `title`
from ((select `n`.`id`          AS `id`,
              0                 AS `event_type`,
              `a`.`create_user` AS `deal_user`,
              `n`.`grade`       AS `grade`,
              `a`.`create_time` AS `create_time`,
              `n`.`title`       AS `title`
       from (`village`.`tt_agriculture_answer` `a` left join `village`.`blade_notice` `n`
             on ((`a`.`notice_id` = `n`.`id`)))
       where ((`n`.`is_grade` = 1) and (`a`.`is_deleted` = 0) and (`n`.`is_deleted` = 0)))
      union all
      (select `e`.`id`               AS `id`,
              (`e`.`event_type` + 1) AS `event_type`,
              `e`.`deal_user`        AS `deal_user`,
              `e`.`grade`            AS `grade`,
              `e`.`create_time`      AS `create_time`,
              `e`.`title`            AS `title`
       from `village`.`tt_upload_event` `e`
       where ((`e`.`is_grade` = 1) and (`e`.`is_deleted` = 0)))) `grade`
order by `grade`.`create_time` desc;

