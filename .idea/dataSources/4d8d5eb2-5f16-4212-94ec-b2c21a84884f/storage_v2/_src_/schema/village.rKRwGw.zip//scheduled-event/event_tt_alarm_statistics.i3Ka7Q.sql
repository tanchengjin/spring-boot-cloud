create definer = root@`%` event event_tt_alarm_statistics on schedule
    every '1' MONTH
        starts '2022-09-01 01:00:00'
    enable
    do
    CALL p_tt_alarm_statistics_all();

