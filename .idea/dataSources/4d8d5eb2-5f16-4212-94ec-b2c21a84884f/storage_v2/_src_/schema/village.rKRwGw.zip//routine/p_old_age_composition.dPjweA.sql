create
    definer = root@`%` procedure p_old_age_composition() comment '统计老人信息年龄构成'
BEGIN
SET SESSION sql_mode = NO_ZERO_IN_DATE;
INSERT INTO tt_statistics ( street_id, dict_key, statistics_name, statistics_value, create_dept, update_time ) SELECT
'1',
'5',
'60-64',
COUNT( ID ) AS statistics_value,
'1',
NOW() 
FROM
	blade_user bu 
WHERE
	street_id <> '' 
	AND street_id <> '-1' 
	AND birthday <> '' 
	AND is_old = '1' 
	AND is_deleted=0
	AND TIMESTAMPDIFF(
		YEAR,
		birthday,
	CURDATE())>= 60 
	AND TIMESTAMPDIFF(
		YEAR,
		birthday,
	CURDATE())<= 64 
	ON DUPLICATE KEY UPDATE statistics_value =
VALUES
	( statistics_value ),
	update_time = NOW();-- 17-30
INSERT INTO tt_statistics ( street_id, dict_key, statistics_name, statistics_value, create_dept, update_time ) SELECT
'1',
'5',
'65-70',
COUNT( ID ) AS statistics_value,
'1',
NOW() 
FROM
	blade_user bu 
WHERE
	street_id <> '' 
	AND street_id <> '-1' 
	AND birthday <> '' 
	AND is_old = '1' 
	AND is_deleted=0
	AND TIMESTAMPDIFF(
		YEAR,
		birthday,
	CURDATE())> 64 
	AND TIMESTAMPDIFF(
		YEAR,
		birthday,
	CURDATE())<= 70 
	ON DUPLICATE KEY UPDATE statistics_value =
VALUES
	( statistics_value ),
	update_time = NOW();-- 大于60
INSERT INTO tt_statistics ( street_id, dict_key, statistics_name, statistics_value, create_dept, update_time ) SELECT
'1',
'5',
'70以上',
COUNT( ID ) AS statistics_value,
'1',
NOW() 
FROM
	blade_user bu 
WHERE
	street_id <> '' 
	AND street_id <> '-1' 
	AND birthday <> '' 
	AND is_old = '1' 
	AND is_deleted=0
	AND TIMESTAMPDIFF(
		YEAR,
		birthday,
	CURDATE())> 70 
	ON DUPLICATE KEY UPDATE statistics_value =
VALUES
	( statistics_value ),
	update_time = NOW();
INSERT INTO tt_statistics ( street_id, dict_key, statistics_name, statistics_value, create_dept, update_time ) SELECT
bu.street_id,
'5',
'60-64',
COUNT( ID ) AS statistics_value,
bu.street_id,
NOW() 
FROM
	blade_user bu 
WHERE
	street_id <> '' 
	AND street_id <> '-1' 
	AND birthday <> ''
	AND is_old = '1'  
	AND is_deleted=0
	AND TIMESTAMPDIFF(
		YEAR,
		birthday,
	CURDATE())>= 60 
	AND TIMESTAMPDIFF(
		YEAR,
		birthday,
	CURDATE())<= 64
GROUP BY
	bu.street_id 
	ON DUPLICATE KEY UPDATE statistics_value =
VALUES
	( statistics_value ),
	update_time = NOW();-- 17-30
INSERT INTO tt_statistics ( street_id, dict_key, statistics_name, statistics_value, create_dept, update_time ) SELECT
bu.street_id,
'5',
'65-70',
COUNT( ID ) AS statistics_value,
bu.street_id,
NOW() 
FROM
	blade_user bu 
WHERE
	street_id <> '' 
	AND street_id <> '-1' 
	AND birthday <> '' 
	AND is_old = '1' 
	AND is_deleted=0
	AND TIMESTAMPDIFF(
		YEAR,
		birthday,
	CURDATE())> 64 
	AND TIMESTAMPDIFF(
		YEAR,
		birthday,
	CURDATE())<= 70
GROUP BY
	bu.street_id 
	ON DUPLICATE KEY UPDATE statistics_value =
VALUES
	( statistics_value ),
	update_time = NOW();-- 大于60
INSERT INTO tt_statistics ( street_id, dict_key, statistics_name, statistics_value, create_dept, update_time ) SELECT
bu.street_id,
'5',
'70以上',
COUNT( ID ) AS statistics_value,
bu.street_id,
NOW() 
FROM
	blade_user bu 
WHERE
	street_id <> '' 
	AND street_id <> '-1' 
	AND birthday <> '' 
	AND is_old = '1' 
	AND TIMESTAMPDIFF(
		YEAR,
		birthday,
	CURDATE())> 70 
GROUP BY
	bu.street_id 
	ON DUPLICATE KEY UPDATE statistics_value =
VALUES
	( statistics_value ),
	update_time = NOW();
	END;

