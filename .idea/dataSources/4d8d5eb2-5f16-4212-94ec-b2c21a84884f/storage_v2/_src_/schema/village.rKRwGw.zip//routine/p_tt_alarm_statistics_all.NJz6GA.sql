create
    definer = root@`%` procedure p_tt_alarm_statistics_all() comment '按月统计告警记录条数'
BEGIN
	INSERT INTO tt_alarm_statistics ( street_id, machine_type_id, month, statistics_value, create_dept, update_time ) SELECT
	1,
	machine_type_id,
	DATE_FORMAT(create_time,'%Y-%m') as month,
	COUNT( ID ) AS statistics_value,
	1,
	NOW()
	FROM
		tt_alarm 
	WHERE
		street_id <> '' 
		AND street_id <> '-1' 
		AND is_deleted=0
		GROUP BY
		machine_type_id,month
		ON DUPLICATE KEY UPDATE statistics_value =
	VALUES
		( statistics_value ),
		update_time = NOW();
		
	INSERT INTO tt_alarm_statistics ( street_id, machine_type_id, month,statistics_value, create_dept, update_time ) SELECT
	street_id,
  machine_type_id,
	DATE_FORMAT(create_time,'%Y-%m') as month,
	COUNT( ID ) AS statistics_value,
	street_id,
	NOW() 
	FROM
		tt_alarm
	WHERE
		street_id <> '' 
		AND street_id <> '-1' 
		AND is_deleted=0
	GROUP BY
		machine_type_id,street_id,month
		ON DUPLICATE KEY UPDATE statistics_value =
	VALUES
		( statistics_value ),
		update_time = NOW();
		
		
		-- 所有县区告警记录条数
	INSERT INTO tt_alarm_statistics ( street_id, machine_type_id, month, statistics_value, create_dept, update_time ) SELECT
	estate_id,
	machine_type_id,
	DATE_FORMAT(create_time,'%Y-%m') as month,
	COUNT( ID ) AS statistics_value,
	estate_id,
	NOW()
	FROM
		tt_alarm 
	WHERE
		estate_id <> '' 
		AND estate_id <> '-1' 
		AND is_deleted=0
		GROUP BY
		machine_type_id,estate_id,month
		ON DUPLICATE KEY UPDATE statistics_value =
	VALUES
		( statistics_value ),
		update_time = NOW();
	INSERT INTO tt_alarm_statistics ( street_id, machine_type_id, month, statistics_value, create_dept, update_time ) SELECT
	1,
	machine_type_id,
	DATE_FORMAT(date_sub(CURRENT_TIMESTAMP, interval 1 month),'%Y-%m') as month,
	COUNT( ID ) AS statistics_value,
	1,
	NOW()
	FROM
		tt_alarm 
	WHERE
		street_id <> ''
		AND street_id <> '-1' 
		AND is_deleted=0
		AND DATE_FORMAT(create_time,'%Y-%m') = DATE_FORMAT(DATE_SUB(CURRENT_TIMESTAMP,INTERVAL 1 MONTH),'%Y-%m')
		GROUP BY
		machine_type_id
		ON DUPLICATE KEY UPDATE statistics_value =
	VALUES
		( statistics_value ),
		update_time = NOW();
		
	INSERT INTO tt_alarm_statistics ( street_id, machine_type_id, month,statistics_value, create_dept, update_time ) SELECT
	street_id,
  machine_type_id,
	DATE_FORMAT(date_sub(CURRENT_TIMESTAMP, interval 1 month),'%Y-%m') as month,
	COUNT( ID ) AS statistics_value,
	street_id,
	NOW() 
	FROM
		tt_alarm
	WHERE
		street_id <> '' 
		AND street_id <> '-1' 
		AND is_deleted=0
		AND DATE_FORMAT(create_time,'%Y-%m') = DATE_FORMAT(DATE_SUB(CURRENT_TIMESTAMP,INTERVAL 1 MONTH),'%Y-%m')
	GROUP BY
		machine_type_id,street_id
		ON DUPLICATE KEY UPDATE statistics_value =
	VALUES
		( statistics_value ),
		update_time = NOW();
		
		
		
		-- 各社区告警记录条数
	INSERT INTO tt_alarm_statistics ( street_id, machine_type_id, month,statistics_value, create_dept, update_time ) SELECT
	estate_id,
  machine_type_id,
	DATE_FORMAT(date_sub(CURRENT_TIMESTAMP, interval 1 month),'%Y-%m') as month,
	COUNT( ID ) AS statistics_value,
	estate_id,
	NOW() 
	FROM
		tt_alarm
	WHERE
		estate_id <> '' 
		AND estate_id <> '-1' 
		AND is_deleted=0
		AND DATE_FORMAT(create_time,'%Y-%m') = DATE_FORMAT(DATE_SUB(CURRENT_TIMESTAMP,INTERVAL 1 MONTH),'%Y-%m')
	GROUP BY
		machine_type_id,estate_id
		ON DUPLICATE KEY UPDATE statistics_value =
	VALUES
		( statistics_value ),
		update_time = NOW();
			
END;

