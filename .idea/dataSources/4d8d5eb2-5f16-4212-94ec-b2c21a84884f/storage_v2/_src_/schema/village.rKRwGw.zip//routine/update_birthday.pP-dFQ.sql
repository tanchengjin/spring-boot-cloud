create
    definer = root@`%` procedure update_birthday()
BEGIN
	DECLARE
		row_id BIGINT ( 20 );#定义变量 ID
	DECLARE
		row_birthday VARCHAR ( 25 );#定义变量生日
	DECLARE
		done INT;-- 定义游标
	DECLARE
		rs_cursor CURSOR FOR SELECT
		id,
		substr( blade_user.id_card, 7, 8 ) AS birthday 
	FROM
		blade_user 
	WHERE
		CAST( substr( blade_user.id_card, 7, 8 ) AS DATE ) IS NOT NULL;
	DECLARE
		CONTINUE HANDLER FOR NOT FOUND 
		SET done = 1;
	OPEN rs_cursor;
	cursor_loop :
	LOOP
			FETCH rs_cursor INTO row_id,
			row_birthday;-- 取数据
		IF
			done = 1 THEN
				LEAVE cursor_loop;
			
		END IF;-- 更新表
		SET SESSION sql_mode = NO_ZERO_IN_DATE;
		IF
			TIMESTAMPDIFF(
				YEAR,
				row_birthday,
				CURDATE())>= 60 THEN
				UPDATE blade_user 
				SET birthday = row_birthday,
				is_old = '1' 
			WHERE
				id = row_id;
			ELSE UPDATE blade_user 
			SET birthday = row_birthday 
			WHERE
				id = row_id;
			END IF;
		END LOOP cursor_loop;
		CLOSE rs_cursor;
	
END;

